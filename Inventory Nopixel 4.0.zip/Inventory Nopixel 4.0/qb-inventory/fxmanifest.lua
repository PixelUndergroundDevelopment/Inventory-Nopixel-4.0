fx_version 'cerulean'
game 'gta5'
lua54 'yes'

shared_scripts {
    'locales/locale.lua',
    -- '@qb-core/shared/locale.lua',
    'data/*.lua',
    'locales/en.lua',
    'locales/*.lua',
    'shared/cores.lua',
    'shared/config.lua'
}

server_scripts {
    'data/*.lua',
	'@oxmysql/lib/MySQL.lua',
    'server/core.lua',
    'server/main.lua',
}

client_scripts{
    'data/*.lua',
    'client/*.lua',
}

escrow_ignore {
    'data/*.lua',
    'shared/*.lua',
    'client/*.lua',
    'server/*.lua',
    'locales/*.lua',
    
  }
  


ui_page {
    'html/ui.html'
}

files {
    'html/ui.html',
    'html/css/main.css',
    'html/js/app.js',
    'html/images/*.png',
    'html/images/*.jpg',
    'html/ammo_images/*.png',
    'html/attachment_images/*.png',
    'html/*.ttf',
    'data/*.lua',
    'client/*.lua',
    'server/*.lua',
}

-- dependency 'qb-weapons'

dependency '/assetpacks'
dependency '/assetpacks'
dependency '/assetpacks'